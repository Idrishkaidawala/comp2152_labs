# monster.py
import random
from character import Character

class Monster(Character):
    def __init__(self, name, combat_strength, health_points, powers):
        """Initialize the Monster with name, combat strength, health points, and powers."""
        super().__init__(name, combat_strength, health_points)
        self.powers = powers  # Dictionary of powers with their respective strength boosts

    def use_power(self):
        """Monster uses one of its powers to boost combat strength."""
        # Select a random power and its corresponding strength boost
        power_name, power_strength = random.choice(list(self.powers.items()))
        self.combat_strength += power_strength
        print(f"{self.name} uses {power_name}, boosting combat strength by {power_strength}!")
        print(f"{self.name}'s new combat strength is {self.combat_strength}.")

# Example usage
if __name__ == "__main__":
    # Define monster powers and their strength boosts
    monster_powers = {"Fire Magic": 2, "Freeze Time": 4, "Super Hearing": 6}
    # Create a Monster instance
    monster = Monster("Fierce Dragon", 4, 20, monster_powers)

    # Display initial stats and apply a random power
    print(f"{monster.name} appears with {monster.health_points} health and {monster.combat_strength} combat strength.")
    monster.use_power()
