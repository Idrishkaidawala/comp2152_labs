# character.py

class Character:
    def __init__(self, name, combat_strength, health_points):
        self.name = name
        self.combat_strength = combat_strength
        self.health_points = health_points

    def attack(self, target):
        """Attack another character."""
        print(f"{self.name} attacks {target.name} with strength {self.combat_strength}!")
        target.take_damage(self.combat_strength)

    def take_damage(self, damage):
        """Take damage from an attack."""
        self.health_points -= damage
        if self.health_points <= 0:
            print(f"{self.name} has been defeated!")
        else:
            print(f"{self.name} now has {self.health_points} health left.")

    def is_alive(self):
        """Check if character is still alive."""
        return self.health_points > 0
