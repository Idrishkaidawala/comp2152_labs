# hero.py
from character import Character

class Hero(Character):
    def __init__(self, name, combat_strength, health_points):
        # Initialize the Hero with the properties of Character class
        super().__init__(name, combat_strength, health_points)

    def use_loot(self, item):
        """Use an item from loot to help the hero."""
        if item == "Health Potion":
            # If health is already at max (20), it does not increase
            self.health_points = min(20, self.health_points + 2)
            print(f"{self.name} used a Health Potion! Health is now {self.health_points}.")
        elif item == "Poison Potion":
            # If health is less than 2, it won't go below 0
            self.health_points = max(0, self.health_points - 2)
            print(f"{self.name} used a Poison Potion! Health is now {self.health_points}.")
        else:
            print(f"{item} is not helpful.")

# Example usage
if __name__ == "__main__":
    # Example Hero initialization and testing
    hero = Hero("Brave Knight", 5, 15)
    print(f"{hero.name} starts with {hero.health_points} health and {hero.combat_strength} combat strength.")
    # Example of using loot
    hero.use_loot("Health Potion")
